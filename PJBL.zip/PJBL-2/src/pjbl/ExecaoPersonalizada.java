package pjbl;

public class ExecaoPersonalizada extends Exception{
	
	ExecaoPersonalizada(String nome){
		super(nome);
	}
	
}
