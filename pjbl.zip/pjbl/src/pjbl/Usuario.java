package pjbl;

import pjbl.Evento;

public class Usuario extends Pessoa{
	
	public Usuario(String nome, String email, String senha) {
		super.nome = nome;
		super.email = email;
		super.id += 1;
		super.senha = validadorSenha(senha);
	}
	
	public void seInscrever(int id) {
		try {
			if (super.eventos.contains(id) == true) {
				//if (Evento.participantes. != Evento.capacidade) {
					
				//}
			}
		}
		
		catch(Exception e) {
			System.out.println("Não foi possivel se inscrever no evento selecionado");
		}
	}
	
	public void cancelarInscrição(int id) {
		try {
			if (super.eventos.contains(id) == true) {
				
			}
		}
		
		catch(Exception e) {
			System.out.println("Não foi possivel cancelar a inscrição neste evento!");
		}
	}
	
}
