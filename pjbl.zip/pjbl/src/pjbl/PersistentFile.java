package pjbl;

public abstract class PersistentFile {
	
}
