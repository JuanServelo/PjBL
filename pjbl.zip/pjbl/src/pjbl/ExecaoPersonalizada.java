package pjbl;

public class ExecaoPersonalizada extends Exception{

}
