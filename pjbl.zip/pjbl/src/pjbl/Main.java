package pjbl;

public class Main {

	public static void main(String[] args) throws Exception {
		Pessoa teste2 = new Usuario("Juan", "Teste", "#Teste2");
		Organizador teste3 = new Organizador("Jorge", "Teste", "#Senha1");
		Evento evento = new Evento("Evento", "20/20/2023", 20, "Testeteststetstetste stat sayuv asiveasnoneb");
		Evento evento2 = new Evento("Eveto", "20/20/2023", 20, "AAAAAAAAFTesteteststasdesadsatstetste stat sayuv asiveasnoneb");
	}

}
