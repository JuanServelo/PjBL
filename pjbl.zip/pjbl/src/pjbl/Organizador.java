package pjbl;

import pjbl.Evento;

public class Organizador extends Pessoa {
	
	public Organizador(String nome, String email, String senha) {
		super.nome = nome;
		super.email = email;
		super.id += 1;
		super.senha = validadorSenha(senha);
	}
	
	private void criarEvento(String nome, String data, int capacidade, String descricao) {
		Evento evento = new Evento(nome, data, capacidade, descricao);
		super.eventos.add(evento);
	}
	
	private void excluirEvento(int id) {
		try {
			if (super.eventos.contains(id) == true) {
				super.eventos.remove(super.eventos.indexOf(id));
				System.out.println("Evento removido com sucesso!");
			}
		}
		catch(Exception e) {
			System.out.println("Não foi possivel remover o evento selecionado!");
		}
	}
	
	private void modificarEvento(int id, String nome, String data, int capacidade, String descricao) {
		try {
			if (super.eventos.contains(id) == true) {
				super.eventos.remove(super.eventos.indexOf(id));
				Evento evento = new Evento(nome, data, capacidade, descricao);
		        //eventos.get(eventos.indexOf(id)).nome = nome;
				//eventos.get(eventos.indexOf(id)).data = data;
				//eventos.get(eventos.indexOf(id)).capacidade = capacidade;
				//eventos.get(eventos.indexOf(id)).descricao = descricao;
				super.eventos.add(evento);
			}
		}
		catch(Exception e ) {
			System.out.println("Não foi possivel modificar o evento selecionado!");
		}
		
	}
	
}
