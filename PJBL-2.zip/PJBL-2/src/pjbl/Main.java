package pjbl;

public class Main {

	public static void main(String[] args) throws Exception {
		Usuario teste = new Usuario("Juan", "Teste", "#Teste");
		Usuario teste2 = new Usuario("Juan", "Teste", "#Teste2");
	}

}
