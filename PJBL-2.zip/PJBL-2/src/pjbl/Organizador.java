package pjbl;

import pjbl.Evento;

public class Organizador extends Pessoa {
	
	public Organizador(String nome, String email, String senha) {
		super.nome = nome;
		super.email = email;
		super.id += 1;
		super.senha = validadorSenha(senha);
		FileManager fm = new FileManager("./database/users.csv");
		fm.adicionarUserLista(super.id, nome, email, super.senha, "organizador");
		fm.adicionarUsers();
	}
	
	private void criarEvento(String nome, String data, int capacidade, String descricao) {
		Evento evento = new Evento(nome, data, capacidade, descricao);
	}
	
	private void excluirEvento(int id) {
		try {
			
		}
		catch(Exception e) {
			System.out.println("Não foi possivel remover o evento selecionado!");
		}
	}
	
	private void modificarEvento(int id, String nome, String data, int capacidade, String descricao) {
		try {
			
		}
		catch(Exception e ) {
			System.out.println("Não foi possivel modificar o evento selecionado!");
		}
		
	}
	
}
