package pjbl;

import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

public class FileManager {
	
	private String caminhoArquivo;
	public String[][] users = {{"ID", "nome", "e-mail", "senha", "tipo usuario"}};
	public String[][] eventos = {{"ID", "nome", "Data", "Capacidade", "Descrição", "Palestrantes", "Participantes"}};
	
	public FileManager(String caminhoArquivo) {
		this.caminhoArquivo = caminhoArquivo;
	}
	
	public void adicionarUserLista(int id, String nome, String email, String senha, String tipoUser) {
		String id_user = "" + id;
		users[0][0] = id_user;
		users[0][1] = nome;
		users[0][2] = email;
		users[0][3] = senha;
		users[0][4] = tipoUser;
	}
	
	public void lerArquivo() {
		File file = new File(caminhoArquivo);
		try {
			Scanner scanner = new Scanner(file);
			String cabecalho = scanner.nextLine();
			System.out.println(cabecalho);
			while (scanner.hasNextLine()) {
				String dado = scanner.nextLine();
				Scanner dadoSeparado = new Scanner(dado).useDelimiter(",");
				System.out.println("ID" + dadoSeparado.nextInt());
				System.out.println("Nome" + dadoSeparado.next());
				System.out.println("Preço" + dadoSeparado.nextInt());
				dadoSeparado.close();
			}
			scanner.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void adicionarUsers() {
		File file = new File(caminhoArquivo);
		try {
			FileWriter fileWriter = new FileWriter(file, true);
			for(String[] valor : users) {
				StringBuilder line = new StringBuilder();
				// esse line está escrevendo tudo no arquivo csv
				for(int cont = 0; cont < valor.length; cont++) {
					// pega os valores que estão armazenados na lista de eventos
					line.append(valor[cont]);
					if(cont != valor.length - 1) {
						line.append(',');
					}
				}
				line.append("\n");
				fileWriter.append(line.toString());
			}
			fileWriter.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
